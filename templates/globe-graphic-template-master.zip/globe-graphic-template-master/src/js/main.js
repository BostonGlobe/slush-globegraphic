(function() {
	'use strict';
	// global variables


	// graphic functions
	var init = function() {
		if (window.console && console.log) console.log('-- init globe graphic --');

	};



	// This fires when the parent of iframe resizes
	window.onPymParentResize = function(width) {
		
	};
	
	init();
})();